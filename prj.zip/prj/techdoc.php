<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Help Page</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <style>
        html {
            overflow-y: scroll;
        }

        .banner {
            font-family: Tahoma, sans-serif;
            background: black;
            margin-top: 0;
            padding: 20px;
        }

        .top {
            text-align: center;
        }

        body {
            font-family: monospace;
            font-size: 20px;
        }

        p {
            text-align: left;
            width: 33%;
        }
    </style>
</head>

<body>
    <h1 class="banner">
        <center>
            <span style="color:#999999">CS-Systems</span>
            <span style="color:#FFFFFF">Course Tracker 2021</span>
        </center>
    </h1>
    <div class="top">
        <h4> Authors: Ahmed Darwich, Zach Pallotta, John Dailey </h4>
    </div>
    <center>
        <a href="http://localhost/isp/prj/prj.php"> Back To Course Tracker</a>
        <h1>Technical Document</h1>
    </center>
    <center>
        <p>
            Our group has decided to create a 5-year BS/MS course tracking website application that will allow users to input the courses they have completed or are currently taken and compare it to the generic schedule that
            the Department of Advising gives to students interested in the 5-year track. This application will also allow students to compare the classes they have taken to the requirements set by the degree progress report.
            It will also allow them to view their past schedule with courses they have taken and the future classes they will take according to the generic schedule. This visual will allow students to understand when they can
            take courses and how their plan looks with all five years together. The database will be designed in two tables. The first table will hold the degree requirements for the 5-year program with some generic classes
            added for the general education categories. The second table will store the user inputs thus meaning the classes they have taken and received credit for. This is planned to be implemented using a SQL database where
            the data access layer will be done through PHP which will allow the logic frontend to be JavaScript. The work will be split evenly among the three members of the team where we will attempt to complete trio
            programming (like pair programming) where we will screen share our coding work. If schedules conflict, the basic responsibility of the database formation will be Zach’s responsibility, the data access layer will be
            John’s responsibility, and the frontend and the UX design will be Ahmed’s – resulting in an even 33% split of responsibility and work.
        </p>
        <p>
            For contribution to this project, Zach created the databases for our course tracker app. Zach also contributed to the PHP layout design. John contributed with the data access to the database, as well as working on
            the documentation for reports. Ahmed contributed by working on the JavaScript for the program, as well as the CSS design.
        </p>
        <p>
            Through this project, we learned a lot of useful tips. We learned how to use integration tools to create a complete product that lines up with what we perceived. We also learned that organizational tools in web
            applications can be confusing to use at times, which can make projects take longer to complete. Since we were working on both the frontend and backend at the same time, it can lead to confusion, which leads to a
            loss in development time. We also learned how to make a tougher task more simplistic through planning and simple thinking. We realized that we can create a progress report, just like the one our own school uses,
            with a simple approach to how it is implemented.
        </p>
        <p>
            In terms of future work, we can apply these concepts into future development opportunities. One of the features we could work on in the future is the bootstrap properly implemented to allow for columns to shift
            when the screen re-sizes. We could not find a solution towards getting the columns to properly align, which makes the project look sloppy at times. Another piece of future work is to implement this through a .NET
            application. Another piece of future work we could work on is the ability to add more majors, as well as adding more gen-ed curriculums to the list. Other pieces of future work are introducing security, such as
            using a login page, two-step authentication, etc. We can make sure that individual users will be able to have their own tables to work on for their specific major.
        </p>
    </center>
</body>

</html>